<@
	require(["./require.conf"]);
	require(["text!./ini.js"],function(conf){
		//handle config
		println(conf);
	});

@>
